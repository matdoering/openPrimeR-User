/*
int locpenaltyd = -2400;
int locoffsetd = -60;
char locaminod[26] = "GASTPLIMVDNEQFYWKRHCXXX.-U";
char locaminod[] = "ARNDCQEGHILKMFPSTWYVBZX.-U";
char locgrpd[] = 
{
	0, 3, 2, 2, 5, 2, 2, 0, 3, 1, 1, 3, 1, 4, 0, 0, 0, 4, 4, 1, 2, 2,
	6, 6, 6, 6,
};
*/
