extern int disttbfast( int ngui, int lgui, char **namegui, char **seqgui, int argc, char **argv, int (*callback)(int, int, char*));
#define GUI_ERROR 1
#define GUI_LENGTHOVER 2
#define GUI_CANCEL 3
