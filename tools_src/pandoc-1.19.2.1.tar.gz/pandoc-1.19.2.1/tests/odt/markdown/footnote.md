Some text[^1] with a footnote.

[^1]: Footnote text