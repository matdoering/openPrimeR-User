Some text[^1] with an endnote.

[^1]: Endnote text